# %%
import random

# from version0 import Hobbit, Wizard
# from version1 import Hobbit, Wizard
# from version2 import Hobbit, Wizard
from middle_earth import Hobbit, Wizard

if __name__ == "__main__":
    FREQ_SPECIAL_MOVE = 0.2
    N_MAX_ROUNDS = 50

    hero1 = Wizard(
        name="Gandalf", health=40, max_damage_point=10, consistency_score=0.8
    )
    hero2 = Hobbit(name="Gollum", health=100, max_damage_point=5, consistency_score=0.2)

    coin_toss = random.choice(["head", "tail"])
    if coin_toss == "head":
        print(f"{hero1.name} attacks first")
        attacker, defender = hero1, hero2
    else:
        print(f"{hero2.name} attacks first")
        attacker, defender = hero2, hero1

    n_rounds = 1
    heros_alive = True
    while n_rounds <= N_MAX_ROUNDS and heros_alive:
        print(f"Round {n_rounds}:")
        rnd_special_move = random.random()
        special_move_round = rnd_special_move < FREQ_SPECIAL_MOVE
        if special_move_round:
            print(f"{attacker.name} uses special move")
            attacker.special_move(defender)
        else:
            print(f"{attacker.name} attacks")
            attacker.attack(defender)

        print("Current status:")
        print(f"{hero1.name} health: {hero1.health}")
        print(f"{hero2.name} health: {hero2.health}")
        heros_alive = defender.health > 0
        attacker, defender = defender, attacker
        n_rounds += 1
        print("=" * 20)

    print("Game over")
    if heros_alive:
        print(f"There is a tie")
    else:
        print(f"{defender.name} wins")
