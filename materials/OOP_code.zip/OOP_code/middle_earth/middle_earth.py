#%%
from abc import ABC, abstractmethod
import random


class Hero(ABC):
    MAX_FREQUENCY_OF_SPECIAL_MOVE = 3

    def __init__(
        self, name: str, health: int, max_damage_point: int, consistency_score: float
    ):
        self.name = name
        self.health = health
        self.max_damage_point = max_damage_point
        self.consistency_score = consistency_score
        self.n_rounds_since_special_move = 0

    def attack(self, other):
        random_number = random.randint(0, self.max_damage_point)
        print("Random number generated for the attack:", random_number)
        effective_damage = int(
            self.consistency_score * self.max_damage_point
            + (1 - self.consistency_score) * random_number
        )
        print("Damage point calculated for the attack:", effective_damage)
        other.health = other.health - effective_damage
        self.n_rounds_since_special_move += 1

    @abstractmethod
    def special_move(self, other):
        pass


class Wizard(Hero):
    def __init__(self, name: str, health: int, damage_point: int, consistency: float):
        super().__init__(name, health, damage_point, consistency)
        self.initial_health = health

    def special_move(self, other):
        if self.n_rounds_since_special_move >= Hero.MAX_FREQUENCY_OF_SPECIAL_MOVE:
            self.health = min(
                self.health + self.initial_health / 2, self.initial_health
            )

        self.n_rounds_since_special_move = 0


class Hobbit(Hero):
    def special_move(self, other):
        if self.n_rounds_since_special_move >= Hero.MAX_FREQUENCY_OF_SPECIAL_MOVE:
            actual_consistency = self.consistency
            self.consistency = 1
            self.attack(other)
            self.consistency = actual_consistency

        self.n_rounds_since_special_move = 0


class Human(Hero):
    def special_move(self, other):
        if self.n_rounds_since_special_move >= Hero.MAX_FREQUENCY_OF_SPECIAL_MOVE:
            other.health = other.health - 2 * self.max_damage_point

        self.n_rounds_since_special_move = 0


class Elf(Hero):
    def special_move(self, other):
        if self.n_rounds_since_special_move >= Hero.MAX_FREQUENCY_OF_SPECIAL_MOVE:
            self.health = other.health

        self.n_rounds_since_special_move = 0


class Dwarf(Hero):
    def special_move(self, other):
        if self.n_rounds_since_special_move >= Hero.MAX_FREQUENCY_OF_SPECIAL_MOVE:
            self.damage_point = 2 * self.damage_point

        self.n_rounds_since_special_move = 0

