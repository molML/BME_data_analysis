#%%
import random


def attack(hero1, hero2):
    random_number = random.randint(0, hero1["max_damage_point"])
    print("Random number generated for the attack:", random_number)
    effective_damage = int(
        hero1["consistency_score"] * hero1["max_damage_point"]
        + (1 - hero1["consistency_score"]) * random_number
    )
    print("Damage point calculated for the attack:", effective_damage)
    hero2["health"] = hero2["health"] - effective_damage
    hero1["n_rounds_since_special_move"] += 1


def wizard_special_move(hero1):
    if hero1["n_rounds_since_special_move"] >= MAX_FREQUENCY_OF_SPECIAL_MOVE:
        hero1["health"] = min(
            hero1["health"] + hero1["initial_health"] / 2, hero1["initial_health"]
        )

    hero1["n_rounds_since_special_move"] = 0


def hobbit_special_move(hero1, hero2):
    if hero1["n_rounds_since_special_move"] >= MAX_FREQUENCY_OF_SPECIAL_MOVE:
        actual_consistency = hero1["consistency_score"]
        hero1["consistency_score"] = 1
        attack(hero1, hero2)
        hero1["consistency_score"] = actual_consistency

    hero1["n_rounds_since_special_move"] = 0


FREQ_SPECIAL_MOVE = 0.2
N_MAX_ROUNDS = 50

MAX_FREQUENCY_OF_SPECIAL_MOVE = 3
hero1 = {
    "name": "gollum",
    "health": 100,
    "max_damage_point": 5,
    "consistency_score": 0.2,
    "n_rounds_since_special_move": 0,
    "type": "hobbit",
}

hero2 = {
    "name": "gandalf",
    "health": 40,
    "max_damage_point": 10,
    "consistency_score": 0.2,
    "n_rounds_since_special_move": 0,
    "type": "wizard",
    "initial_health": 40,
}


coin_toss = random.choice(["head", "tail"])
if coin_toss == "head":
    print(f"{hero1['name']} attacks first")
    attacker, defender = hero1, hero2
else:
    print(f"{hero2['name']} attacks first")
    attacker, defender = hero2, hero1


n_rounds = 1
heros_alive = True
while n_rounds <= N_MAX_ROUNDS and heros_alive:
    print(f"Round {n_rounds}:")
    rnd_special_move = random.random()
    special_move_round = rnd_special_move < FREQ_SPECIAL_MOVE
    if special_move_round:
        print(f"{attacker['name']} uses special move")
        if attacker["type"] == "wizard":
            wizard_special_move(attacker)
        elif attacker["type"] == "hobbit":
            hobbit_special_move(attacker, defender)
    else:
        print(f"{attacker['name']} attacks")
        attack(attacker, defender)

    print("Current status:")
    print(f"{hero1['name']} health: {hero1['health']}")
    print(f"{hero2['name']} health: {hero2['health']}")
    heros_alive = defender["health"] > 0
    attacker, defender = defender, attacker
    n_rounds += 1
    print("=" * 20)

print("Game over")
if heros_alive:
    print(f"There is a tie")
else:
    print(f"{defender['name']} wins")

