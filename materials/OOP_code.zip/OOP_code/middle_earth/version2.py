# %%
# Further improving the OOP structure with abstract method, class and static variable
from abc import ABC, abstractmethod
import random


class Hero(ABC):
    MAX_FREQUENCY_OF_SPECIAL_MOVE = 3

    def __init__(self, name, health, max_damage_point, consistency_score) -> None:
        self.name = name
        self.health = health
        self.max_damage_point = max_damage_point
        self.consistency_score = consistency_score
        self.initial_health = health
        self.n_rounds_since_special_move = 0

    def attack(self, other):
        random_number = random.randint(0, self.max_damage_point)
        print("Random number generated for the attack:", random_number)
        effective_damage = int(
            self.consistency_score * self.max_damage_point
            + (1 - self.consistency_score) * random_number
        )
        print("Damage point calculated for the attack:", effective_damage)
        other.health = other.health - effective_damage
        self.n_rounds_since_special_move += 1

    @abstractmethod
    def special_move(self, other):
        pass


class Hobbit(Hero):
    def special_move(self, other):
        if self.n_rounds_since_special_move >= Hero.MAX_FREQUENCY_OF_SPECIAL_MOVE:
            actual_consistency = self.consistency_score
            self.consistency_score = 1
            self.attack(other)
            self.consistency_score = actual_consistency

        self.n_rounds_since_special_move = 0


class Wizard(Hero):
    def __init__(self, name, health, max_damage_point, consistency_score) -> None:
        super().__init__(name, health, max_damage_point, consistency_score)
        self.initial_health = health

    def special_move(self, other):
        if self.n_rounds_since_special_move >= Hero.MAX_FREQUENCY_OF_SPECIAL_MOVE:
            self.health = min(
                self.health + self.initial_health / 2, self.initial_health
            )

        self.n_rounds_since_special_move = 0


if __name__ == "__main__":
    hero1 = Wizard(name="Gandalf", health=40, max_damage_point=10, consistency_score=1)
    hero2 = Hobbit(name="Gollum", health=100, max_damage_point=5, consistency_score=0.2)

    hero1.attack(hero2)
    print(hero2.health)
