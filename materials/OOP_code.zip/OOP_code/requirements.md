# A Card Game at Middle Earth

We will implement a simple two-player card game where players aim to kill the other's card by taking turns.

## Outline
- The game is played with 2 players. Each player chooses a card, or a *Hero*. The goal of the game is to kill the opponent's hero. 
- There are 5 Hero types in the game: *Wizard*, *Hobbit*, *Human*, *Elf*, and *Dwarf*. 
- Each hero has a *name*, *health point*, *maximum damage point*, *consistency score*, and *special move* that is specific to its hero type (e.g. wizard).
- At each round, a player either attacks the other player's hero or attempts to leverage its hero's special move which may or may not entail an attacking move (e.g. increasing its own health or consistency score).
- The game has a maximum round number. The game ends either one of the character's health drop to 0 or below, or the maximum round number is reached. The game is called a tie in the latter scenario.

## Attacking
- When a hero attacks the other, the attacker's maximum damage point and consistency is taken into account to compute *an effective damage*, ($d$). The effective damage is computed as $d = c * D + (1 - c) * r$ where
  - $D$ is the maximum damage point of the attacker,
  - $c$ is the consistency score that is between 0 and 1, and
  - $r$ is a random number between 0 and $D$ (inclusive) that is drawn at each round.
- The effective damage is deduced from the other character's health after each attack. The attacker wins the game if the defender's health drops to 0 or below.

## Special Moves
- Special moves can be used per a certain number of rounds that is determined before the game starts.
- Each hero's special attack is specific to its hero type and described below:
  - **Hobbit**: Attacks with a consistency of 1 in that round.
  - **Human**: Attacks with an effective damage of two times their maximum damage point
  - **Wizard**: Increases their health by half of their starting health, with a cap on the starting health.
  - **Elf**: Sets its own health to the opponent's health, leaving the opponent's health unchanged.
  - **Dwarf**: Doubles their maximum damage point for the rest of the game.
 